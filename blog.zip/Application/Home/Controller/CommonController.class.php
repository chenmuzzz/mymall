<?php
/**
 * 公共控制器
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/9
 * Time: 13:11
 */
namespace Home\Controller;
use Think\Controller;

class CommonController extends Controller{
    public function _initialize()
    {
//        parent::__construct();
            $this->getCartInfo();
            $this->getGoodsCate();
    }

    /*
     * 获取公共头部显示的购物车信息
     */
    public function getCartInfo(){
        if(session('?uid')){
            $head_cart=D('cart')->getTotalByCart();
        }else{
            $head_cart=D('cart')->getTotalByCookie();
        }
//        dump($head_cart);die;
        $this->assign('head_cart',$head_cart);
    }
    /*
     * 获取头部公共商品列表部分
     */
    public function getGoodsCate(){
        $goods_cate=M('cate')->select();
        $this->assign('goods_cate',$goods_cate);
    }
}