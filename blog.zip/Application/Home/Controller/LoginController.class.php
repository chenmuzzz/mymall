<?php
/**
 * 登陆控制器
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/7
 * Time: 19:14
 */
namespace Home\Controller;

class LoginController extends CommonController{
	public function login(){
	    if(IS_POST){
            $model=M('user');
//            $data=$model->create();
            $data=I('post.');
//dump($data);die;
            $res=$model->where(array('user_name'=>$data['username'],'user_pwd'=>md5($data['password'])))->find();
//            echo $model->_sql();die;
            if($res){
                session('uid',$res[id]);
                session('username',$data['username']);
//                if($data['remember'] == 1){
//                    cookie('uid',$res);
//                    cookie('username',$data['username']);
//                }
                $this->success('登陆成功',U('index/index'));
            }else{
                $this->error('登陆失败,用户名或密码不正确');
            }
            die;
        }

	    $this->display();
	}
	/*
	 * 用户注册
	 */
	public function register(){
        if(IS_POST){
//            $data=I('post.');
            $model=D('user');
            $datas=$model->create();
            if(!$datas){
                $this->error($model->getError());
            }
            $res=$model->add($datas);
            if($res){
                $this->success('恭喜,注册成功',U('login'));
            }else{
                $this->error('注册失败了哦');
            }
        }

		$this->display();
	}
    /*
    * 安全退出登录
    */
	public function logout(){
	    session(null);
	    if(!session('?uid')){
	        $this->success('安全退出成功');
        }
    }
	/*
	 * 验证码
	 */
    public function vertify(){
        $config=array(
            'fontSize'=>10,
            'useCurve'=>false,   //是否混淆曲线
            'useNoise'=>false,   //是否添加杂点
            'imageH'=>20,           //验证码高度
            'imageW'=>80,            //验证码宽度
            'useZh'=>false,           //是否使用中文
            'length'=>4                //验证码位数
        );
        $verify=new \Think\Verify($config);
        $verify->entry();
    }
    public function getIp(){
//        $ip=get_client_ip();
        $ip='144.3.0.4';
        //初始化类操作
        $location = new \Org\Net\IpLocation('qqwry.dat');
        $data=$location ->getlocation($ip);
//        dump($data);
        $str = $data['country'].$data['area'];
        //转码为 utf-8
        $str=iconv('gb2312','utf-8',$str);
        echo $str;
    }

}

