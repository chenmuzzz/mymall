<?php
/**
 *  购物车控制器
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/8
 * Time: 19:27
 */
namespace Home\Controller;

class CartController extends CommonController
{
    public function zz(){
        dump(cookie());
//       cookie(null);
    }
    public function cartList(){
        if(session('?uid')){
            //登陆用户
            $cart_data=M('cart')->where('user_id='.session('uid'))->select();
            foreach ($cart_data as $key=>$value){
                    $goods_data=M('goods')->find($value['goods_id']);
//                    echo $value['goods_id'];die;
//                    dump($goods_data);die;
                    $cart_data[$key]['goods_name']=$goods_data['goods_name'];
                    $cart_data[$key]['goods_mprice']=$goods_data['goods_mprice'];
                    $cart_data[$key]['goods_smallpic']=$goods_data['goods_smallpic'];
                    $cart_data[$key]['subtotal']=$value['number'] * $value['goods_price'];
                    //将该JSON字段 转码    true 表示转为数组格式
                    $cart_data[$key]['goods_attr']=json_decode( $cart_data[$key]['goods_attr'],true);
            }
//            dump($cart_data);die;
        }else{
            //未登陆用户
            $cart_data=unserialize(cookie('goods_cart'));
//            dump($cart_data);die;
            foreach($cart_data as $key=>$value){
                    $goods_data=M('goods')->find($key);
                    $cart_data[$key]['goods_name']=$goods_data['goods_name'];
                    $cart_data[$key]['goods_mprice']=$goods_data['goods_mprice'];
                    $cart_data[$key]['goods_smallpic']=$goods_data['goods_smallpic'];
                    $cart_data[$key]['subtotal']=$value['number'] * $value['goods_price'];
            }
//            dump($cart_data);die;
        }
        $this->assign('cart_data',$cart_data);
        $this->display();
    }

    public function cartAdd(){
        $data=I('post.');

        foreach($data['goods_attr'] as $key=>$row){
                $data['goods_attr'][$key]=$data['goods_attr'][$key][0];
        }
        if(session('?uid')){
            $data['user_id']=session('uid');
            $data['goods_attr']=json_encode($data['goods_attr']);
//            dump($data);die;
            $where=array('goods_id'=>$data['goods_id'],'user_id'=>session('uid'));
            $res=M('cart')->where($where)->find();
            if($res){
                M('cart')->where($where)->setInc('number',1);
            }else{
                $res=M('cart')->add($data);
                if($res){
                    $this->success('添加至购物车成功');
                }
            }

        }else{
            //尚未登陆用户
            //判断COOKIE是否存在
            if(cookie('goods_cart')){
                //设置flag 判断是否加入了相同的商品
                $p=0;
                $datas=unserialize(cookie('goods_cart'));
                //判断是否添加了相同的商品
                foreach ($datas as $key=>$value){
                    if($data == $datas[$key]){
                        $datas[$key]['number']++;
                        $p=1;
                        break;
                    }
                }
                if($p==0){
                        $datas[$data['goods_id']]=$data;
                }

            }else{
                $datas[$data['goods_id']]=$data;
            }
            $str=serialize($datas);
            cookie('goods_cart',$str);
        }
        //给ajax传递数据
        $a_data=unserialize(cookie('goods_cart'));
        $ajax_cart=D('cart')->getTotalByCookie();
        echo json_encode($ajax_cart);
//        $this->redirect('cart/cartList');
    }
    /*
     * 删除购物车的商品
     */
    public function cartDel(){
        $id=I('goods_id');
        //判断用户是否登陆
        if(session('?uid')){
            $goods_id=I('goods_id');
//            dump($goods_id);die;
            $res=M('cart')->where(array('goods_id'=>$goods_id))->delete();
            if($res){
                $this->success('登陆成功');
            }else{

            }
        }else{
            $data=unserialize(cookie('goods_cart'));
            unset($data[$id]);
            $str=serialize($data);
            cookie('goods_cart',$str);
            $this->success('登陆成功');
        }
    }
    /*
     * 修改购物车的商品
     */
    public function cartEdit(){
        if(session('?uid')){
            $data=I('post.');
            M('cart')->where(array('goods_id'=>$data['goods_id'],'user_id'=>session('uid')))->save(array('number'=>$data['number']));
        }else{
            //未登录用户
            $data=I('post.');
            $cart_data=unserialize(cookie('goods_cart'));
//dump($cart_data);die;
            $goods_id=$data['goods_id'];
            $cart_data[$goods_id]['number']=$data['number'];
            $str=serialize($cart_data);
            cookie('goods_cart',$str);
        }
    }

}