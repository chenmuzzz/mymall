<?php
/**
 * 订单控制器
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/10
 * Time: 19:02
 */

namespace Home\Controller;


class OrderController extends CommonController
{
        /*
         * 进入订单页面
         */
        public function buy(){
            if(IS_POST){
                //展示商品信息
                $data=I('post.');
                //商品的基本信息 转化为字符串
                $buy_data=serialize($data);

                $goods_data=M('goods')->where('id='.$data['goods_id'])->find();
                $data['goods_name']=$goods_data['goods_name'];
                $data['goods_mprice']=$goods_data['goods_mprice'];
                $data['subTotal']=$data['goods_price']*$data['number'];
                //总价
                $total=$data['subTotal'];
                $order_data[]=$data;
                //展示购物者的基本信息
                $buyer_data=M('location')->where('user_id='.session('uid'))->select();
//                dump($buyer_data);
                $this->assign('total',$total);
                //将基本信息传递给模板 放入隐藏域
                $this->assign('buy_data',$buy_data);
                $this->assign('buyer_data',$buyer_data);
                $this->assign('order_data',$order_data);
                $this->display();
            }else{
                $this->display();
            }

        }
        /*
         * 生成订单
         */
        public function orderAdd(){
            $model=M('order');
            $data=$_POST;
            $order_data=$model->create($data);
            //基本订单表入库
            //增加基本信息
            $order_data['order_number']=date('YmdHis').session('uid');
            $order_data['user_id']=session('uid');
            $order_data['order_addtime']=time();
            $order_data['order_price']=$data['total'];
            $order_id=$model->add($order_data);

            //组装 商品订单表数据 入库
            $goods_order['order_id']=$order_id;
            $goods_data=unserialize($data['buy_data']);
            $goods_order['user_id']=session('uid');
            $goods_order['og_price']=$goods_data['goods_price'];
            $goods_order['og_number']=$goods_data['number'];
            $goods_order['og_total_price']=$goods_data['number'] * $goods_data['goods_price'];
            $goods_order['og_goods_attr']=serialize($goods_data['goods_attr']);
            $goods_order['og_goods_id']=$goods_data['goods_id'];
            $res=M('goods_order')->add($goods_order);
            if($res){
                $this->redirect('order/orderInfo',array('oid'=>$order_id));
            }else{
                $this->error('添加失败');
            }
        }

        /*
         * 订单最终详情信息
         */
        public function orderInfo(){
            $oid=I('oid');
            $order_data=M('order')->where(array('id'=>$oid,'user_id'=>session('uid')))->find();
            $this->assign('order_data',$order_data);
            $this->display();
        }

        /*
         * 创建 支付宝  支付方法
         */
        public function pay(){
            $oid=I('oid');
            //查询订单基本信息
            $order_data=M('order')->where(array('user_id'=>session('uid'),'oid'=>$oid))->find($oid);
            $order_data['title']='子龙商城';
            $order_data['body']='哎哟不错哦';
            //引入支付宝 使用vendor
            vendor('alipay.alipay_submit#class');
            //配置文件
            $alipay_config=C('PAY_ALIPAY');
            //构造要请求的参数数组，无需改动
//            dump($alipay_config);die;
            $parameter = array(
                "service"       => $alipay_config['service'],
                "partner"       => $alipay_config['partner'],
                "seller_id"  => $alipay_config['seller_id'],
                "payment_type"	=> $alipay_config['payment_type'],
                "notify_url"	=> $alipay_config['notify_url'],
                "return_url"	=> $alipay_config['return_url'],

                "anti_phishing_key"=>$alipay_config['anti_phishing_key'],
                "exter_invoke_ip"=>$alipay_config['exter_invoke_ip'],
                "out_trade_no"	=> $order_data['order_number'],
                "subject"	=> $order_data['title'],
                "total_fee"	=> $order_data['order_price'],
                "body"	=> $order_data['body'],
                "_input_charset"    => trim(strtolower($alipay_config['input_charset'])),
            );
            //实例化
            $alipaySubmit = new \AlipaySubmit($alipay_config);
            $html_text = $alipaySubmit->buildRequestForm($parameter,"get", "确认");
            echo $html_text;

        }

}


















