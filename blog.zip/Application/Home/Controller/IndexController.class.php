<?php
namespace Home\Controller;

class IndexController extends CommonController {
    public function index(){
        //查询 品牌 及其对应的分类信息
        $cate_brand=M('cate')->alias('b')->join('left join brand as a on a.brand_cate=b.id')->select();
        //转化数组格式 方便遍历
         foreach($cate_brand as $k=>$v){
                 $cate_data[$v['cate_name']][]=$v['brand_name'];
         }
        $this->assign('cate_data',$cate_data);
        $this->display();
    }
}