<?php
/**
 * 商品控制器
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/7
 * Time: 19:14
 */

namespace Home\Controller;

class GoodsController extends CommonController
{
    public function goodsList(){
       //按条件查询所有商品
        $cate_id=I('cate_id')?I('cate_id'):0;
        $where='goods_status=1 and cate_id='.$cate_id;
            //获取品牌条件
        $brand_id = I('brand_id') ? I('brand_id') : 0;
            //获取价格条件
        $goods_price = I('goods_price' ) ? I('goods_price') : 0;
        $price_arr=explode('-',$goods_price);
        if($brand_id){
            $where .=' and brand_id='.$brand_id;
        }
        if($goods_price){
            $where .=' and goods_price>'.$price_arr[0].' and goods_price<'.$price_arr[1];
        }

        $goods_data=M('goods')->where($where)->select();
//        echo M('goods')->_sql();die;
        //查询品牌类型
        $brand_data=M('brand')->where(array('brand_cate'=>$cate_id))->select();
        //获取价格数据
        $this->assign('price_data',getPrice());
        //传递当前价格和品牌 品牌类型
        $this->assign('cate_id',$cate_id);
        $this->assign('brand_id_now',$brand_id);
        $this->assign('goods_price_now',$goods_price);

        $this->assign('brand_data',$brand_data);
        $this->assign('goods_data',$goods_data);
        $this->display();
    }

    public function goodsDetail(){
        //商品ID
        $id=I('goods_id');
        $model=M('goods');
        //访问量自增
        $model->where('id='.$id)->setInc('goods_click',1);
        //查询对应商品的信息和 品牌
        $data=$model->alias('a')->field('a.*,b.brand_name,b.brand_status')->join('left join brand as b on a.brand_id=b.id')->where(array('a.id'=>$id))->find();
        //查询对应商品的 相册列表

        $pic_data=M('pic')->where('goods_id='.$id)->select();
        $this->assign('pic_data',$pic_data);
        //查询对应商品的属性
//        $goods_attr_data=$model->alias('a')->join('left join goods_attr as b on a.id=b.goods_id')->where(array('a.id'=>$id))->select();
        $goods_attr_data=M('goods_attr')->alias('a')->join('left join attribute as b on a.attr_id=b.id')->where(array('a.goods_id'=>$id,'b.attr_sel'=>1))->select();
        foreach($goods_attr_data as $key=>$row){
//            echo '$key是'.$key;
//            dump($goods_attr_data[$key]) ;
//            dump($row);
            /*
             * ????????????????????????/
             */
            //？？？？为何不能使用$row?????????????????????????????????
            $goods_attr_data[$key]['goods_attr_val']=explode(',', $row['goods_attr_val']);
        }
        $this->assign('goods_attr_data',$goods_attr_data);
//        dump($goods_attr_data);die;
        $this->assign('data',$data);
        $this->display();
    }
}