<?php
/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/9
 * Time: 12:48
 */
namespace Home\Model;
use Think\Model;

class CartModel extends Model{
    /*
     * 通过cookie 计算 购物车的价格总和
     */
    public function getTotalByCookie(){
        $data=unserialize(cookie('goods_cart'));
        $sum=0;
        foreach($data as $value){
            $sum +=$value['number'] * $value['goods_price'];
        }
        $a['total']=$sum;
        $a['count']=empty($data)?0:count($data);
        return $a;
    }

    /*
     * 通过数据库计算 购物车的价格 及商品数量
     */
    public function getTotalByCart(){
        $data=M('cart')->where(array('user_id'=>session('uid')))->select();
        $a['count']=0;
        $a['total']=0;
        foreach ($data as $value){
            $a['count']+=$value['number'];
            $a['total']+=$value['number']*$value['goods_price'];
        }
       return $a;
    }
}