<?php
/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/8
 * Time: 13:27
 */
namespace Home\Model;
use Think\Model;

class UserModel extends Model{
    //设置表单的自动验证
    protected $_validate=array(
        array('user_name','require','用户名不能为空'),
        array('user_pwd','require','密码不能为空'),
        array('user_pwd2','user_pwd','两次密码输入不一致哦',0,'confirm'),
        array('user_email','email','不是正确的邮箱格式哦- -')
    );
    protected function _before_insert(&$datas,$options){
        $datas['user_addtime']=time();
        $datas['user_pwd']=md5($datas['user_pwd']);
    }
}