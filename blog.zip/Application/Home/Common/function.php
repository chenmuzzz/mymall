<?php
/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/7
 * Time: 21:24
 */
function getPrice(){
    $arr=array(
        '200-2000'=>'200-2000',
        '2000-4000'=>'2000-4000',
        '4000-6000'=>'4000-6000',
    );
    return $arr;
}