<?php
/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/5/28
 * Time: 21:01
 */
namespace Admin\Model;
use Think\Model;
class GoodsModel extends Model{

}