<?php

/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/5/28
 * Time: 8:27
 */
namespace Admin\Model;
use Think\Model;
header('content-type:text/html;charset=utf-8');
class BrandModel extends Model
{
    protected $_validate=array(
        array('brand_name','require','不能为空')
    );
    protected $_map=array(
      //表单名称 => 字段名称
        array('name'=>'brand_name')
    );
    public function getList(){
        return $data=$this->where('brand_status=1')->select();
    }
}