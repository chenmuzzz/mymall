<?php
/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/5
 * Time: 20:42
 */

namespace Admin\Controller;
class AttributeController extends CommonController
{
    public function attributeList(){
        $model=M('attribute');
        $data=$model->alias('a')->join('left join cate as b on a.cate_id=b.id')->select();
        $this->assign('data',$data);
        $this->display();
    }
    public function attributeAdd(){
        if(IS_POST){
        $data=I('post.');
        $data['attr_val']=str_replace('，',',',$data['attr_val']);
        $res=M('attribute')->add($data);
        if($res){
            $this->success('添加属性成功',U('attributeList'));
        }else{
            $this->error('添加属性失败');
        }
        }
        //查询说有商品类型
        $model=M('cate');
        $this->assign('data',$model->select());
        $this->display();
    }
    //返回ajax请求的数据
    public function sendAjax(){
        $id=I('cate_id');
        $model=M('attribute');
        $data=$model->where(array('cate_id'=>$id))->select();
        echo  json_encode($data);
    }
}