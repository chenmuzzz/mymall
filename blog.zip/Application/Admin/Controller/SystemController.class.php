<?php
/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/4
 * Time: 20:34
 */
namespace Admin\Controller;
class SystemController extends CommonController{
    public function menuList(){
        $model=M('menu');
        $data=$model->select();
        $data=getTree($data);
//        dump($data);die;
        $this->assign('data',$data);
        $this->display();

    }
    public function menuAdd(){
        if(IS_POST){
            $data=I('post.');
            $model=M('menu');
            $res=$model->add($data);
            if($res){
                $this->success('添加成功',U('menuList'));
            }else{
                $this->error('添加失败',U('menuList'));
            }
        }
        $model=M('menu');
        $menu_data=$model->select();
//        $menu_data=list_to_tree($menu_data);
        $menu_data=getTree($menu_data);
//        dump($menu_data);die;
        $this->assign('menu_data',$menu_data);
        $this->display();
    }
    public function roleList(){
        $model=M('role');
        $data=$model->select();
        $this->assign('data',$data);
        $this->display();
    }
    public function roleAdd(){
        if(IS_POST){
            $data=I('post.');
            $model=M('role');
            $res=$model->add($data);
            if($res){
                $this->success('添加角色成功',U('roleList'));
            }else{
                $this->error('添加失败');
            }
            die;
        }
        $this->display();
    }
/*
 * 权限列表显示
 */
    public function accessList(){
        //查询当前角色信息
        $id=I('id');
        $model=M('role');
        $data=$model->find($id);
        $this->assign('data',$data);
//查询所有菜单信息
        $menu_model=M('menu');
        $menu_data=$menu_model->select();
        $menu_data=list_to_tree($menu_data);
//        dump($menu_data);die;
//        select * from role as a left join access as b on a.id=b.role_id
//        dump($menu_data[0]['_child']);die;
        //查询当前角色的权限信息
        $access_model=M('access');
        $access_data=$access_model->field('menu_id')->where('role_id='.$id)->select();
//        dump($access_data);die;
        //将二维数组转化为一维数组
//        dump($access_data);die;
        foreach($access_data as $row){
            foreach ($row as $value){
                $acc_data[]=$value;
            }
        }
//        dump($acc_data);die;
        $this->assign('access_data',$acc_data);
        $this->assign('menu_data',$menu_data);
        $this->display();
    }
    public function accessEdit(){
        $data=I('post.');
        $model=M('access');
        $role_id=$data['role_id'];
        $model->where('role_id='.$role_id)->delete();
        foreach($data['menus'] as $key=> $row){
            $arr[$key]['role_id']=$data['role_id'];
            $arr[$key]['menu_id']=$row;
        }

        $res=$model->addAll($arr);
        if($res){
            $this->success('修改权限成功',U('accessList','id='.$role_id));
        }else{
            $this->error('修改失败');
        }
    }
}