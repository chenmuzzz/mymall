<?php
/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/4
 * Time: 20:00
 */
namespace Admin\Controller;
use Think\Controller;

class CommonController extends Controller{
    public function _initialize(){
        if(!session('?a_username')){
            $this->error('请登陆后再访问',U('login/login'));
        }


        //防止权限翻墙
        //添加超级用户  无需验证权限
        if(session('a_username')!='chenmu'){
            $model=M('access');
            $data=$model->where(array('a.role_id'=>session('rid'),'b.pid'=>array('neq',0)))->alias('a')->join('left join menu as b on a.menu_id=b.id')->select();
            foreach ($data as $row){
                $menu_access[]=strtolower($row['menu_controller'].$row['menu_action']);
            }
            $c_a=strtolower(CONTROLLER_NAME.ACTION_NAME);
            if(!in_array($c_a,$menu_access)){
                $this->error('你没有当前权限');die;
            }
        }



    }
}