<?php
namespace Admin\Controller;
class IndexController extends CommonController {
    public function index(){
        $this->display();
    }
    public function left(){
        $model=M('access');
        $data=$model->alias('a')->where(array('a.role_id'=>session('rid'),'b.is_show'=>1))->join('left join menu as b on a.menu_id = b.id')->select();
        $data=list_to_tree($data);
//        dump($data);die;
        $this->assign('data',$data);
        $this->display();
    }
    public function right(){
    	$this->display();
    }
    public function head(){
    	$this->display();
    }
}