<?php
namespace Admin\Controller;
use Think\Controller;
class LoginController extends Controller{
	public function login(){
	    if(IS_POST){
	        $data=I('post.');
	        $vertify=new \Think\Verify();
	        if(!$vertify->check($data['captcha'])){
	            $this->error('验证码错误',U('login'),1);
            }
            $user=M('admin');
//            $res=$user->where("username='".$data['admin_user']."' and password='".$data['admin_psd']."'" )->find();
            $res=$user->where(array('username'=>$data['admin_user'],'password'=>$data['admin_psd']))->find();
            if($res){
                session('a_uid',$res['id']);
                session('a_username',$res['username']);
                //添加角色信息
                session('rid',$res['role_id']);
                $this->success('登陆成功',U('index/index'),1);
            }else{
                $this->error('用户名或密码不正确',U('login'),1);
            }
            die;
        }
	    $this->display();
	}
	public function vertify(){
	    $config=array(
	        'fontSize'=>10,
	        'useCurve'=>false,   //是否混淆曲线
            'useNoise'=>false,   //是否添加杂点
            'imageH'=>20,           //验证码高度
            'imageW'=>80,            //验证码宽度
            'useZh'=>false,           //是否使用中文
            'length'=>3                //验证码位数
        );
        $verify=new \Think\Verify($config);
        $verify->entry();
    }
    public function loginOut(){
	    //删除session
        session(null);
        if(!session('?username')){
            $this->success('退出成功',U('login'));
        }

    }
}