<?php
/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/5/28
 * Time: 19:13
 */
namespace Admin\Controller;
class BrandController extends CommonController{
    /*
     * 加载品牌列表
     */
    public function brandlist(){
        $model=M('Brand');
        //获取表总记录
        $res=$model->alias('a')->join('left join cate as b on b.id=a.brand_cate')->where('a.brand_status=1')->select();
//        dump($res);
        $this->assign('res',$res);
        $this->display();
    }
    /*
     * 加载添加品牌页面
     */
    public function brandadd(){
        if(IS_POST){
            $model=D('Brand');
            $data=$model->create();
            if(!$data){
                $this->error($model->getError());
            }
            $res=$model->add();
          if($res){
              $this->success('插入成功',U('brandlist'),2);
          }else{
              $this->error('插入失败');
          }
          exit;
        }

       //查询分类信息
        $cate_data=M('cate')->select();
        $this->assign('cate_data',$cate_data);
        $this->display();
    }
/*
 * 修改品牌操作
 */
    public function edit(){
        if(IS_POST){
            $datas=I('post.');
//            dump($datas);
            $model=M('Brand');
            $res=$model->save($datas);
           if($res){
            $this->success('成功了',U('brandlist'),2);
        }else{
            $this->error('修改失败');
        }
    }else{
$id=I('id');
echo $id;
//            dump($data);die;s
$model=M('Brand');
$res=$model->find($id);
$this->assign('res',$res);
            //获取分类信息
            $cate_data=M('cate')->select();
            $this->assign('cate_data',$cate_data);
$this->display();
}

    }
/*
 * 品牌删除功能
 */
    public function delete(){
     //物理删除
//        $id=I('id');
//        $model = M('Brand');
//        $res=$model->delete($id);
//        if($res){
//            $this->success('删除成功',U('brandlist'),0.5);
//        }else{
//            $this->error('删除失败');
//        }
      //逻辑删除
        $id=I('id');
        $model=M('brand');
        $arr['id']=$id;
        $arr['brand_status']=0;
        $res=$model->save($arr);
        if($res){
            $this->success('删除成功',U('brandlist'));
        }else{
            $this->error('删除失败',U('brandlist'));
        }
    }
}
