<?php
/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/5/28
 * Time: 21:03
 */
namespace Admin\Controller;
class GoodsController extends CommonController{
    public function goodsList(){
        $model=M('goods');
        $count=$model->count();
        //实例化分页方法 【初始化总记录数，每页显示格式】
        $page=new \Think\Page($count,6);
        $page->setConfig('next','下一页');
        $page->setConfig('prev','上一页');
        //根据页面获取相应的数据，limit(起始位置，每页显示的个数); 【firstRow,listRows】
        $data=$model->field('a.*,b.brand_name')->table('goods as a,brand as b')->where(array('a.brand_id=b.id'))->limit($page->firstRow.','.$page->listRows)->select();
        //显示分页数据
//        echo $model->_sql();
//        dump($data);die;
        $pages=$page->show();
        $this->assign('pages',$pages);
        //显示详细信息
//       $data=$model->where()->select();
       $this->assign('data',$data);
       $this->display();
    }
    public function goodsAdd(){
        if(IS_POST) {
//            $data = I('post.');
            $data=$_POST;
//            dump($data);die;
//图片上传
//        dump($_FILES);die;
            //确定用户是否上传了图片
            if($_FILES['goods_image']['name']!=''){
            //上传配置
               $res=uploadFile();
                //保存大图
                    $data['goods_bigpic']=$res['goods_image']['savepath'].$res['goods_image']['savename'];

                    $image=new \Think\Image();
                    $image->open(UPLOAD.$data['goods_bigpic']);
                    $image->thumb(100,100)->save(UPLOAD.$res['goods_image']['savepath'].'thumb_'.$res['goods_image']['savename']);
                //保存缩略图
                    $data['goods_smallpic']=$res['goods_image']['savepath'].'thumb_'.$res['goods_image']['savename'];

            }else{
                $noFile = ',但是没有文件被上传哦';
            }


            $data['goods_descrition']=htmlpurifier($data['goods_descrition']);
            $model=M('goods');
            $res=$model->add($data);
            dump($res);
            if($res){
                //把商品属性添加入 goods_attr 表
                foreach($data['goods_attr'] as $key=>$row){
                    $attr_datas[]=array(
                        'goods_id'=>$res,
                        'attr_id'=>$key,
                        'goods_attr_val'=>implode(',',$row),
                    );
                }
//                dump($attr_datas);die;
                $res=M('goods_attr')->addAll($attr_datas);
                if($res){
                    $this->success('添加成功'.$noFile,U('goodsList'));
                }else{
                    $this->error('商品属性写入失败');
                }

            }else{
                $this->error('添加失败',U('goodsList'));
            }


        }
        //查询品牌列表
        $data=D('brand')->getList();
        $this->assign('data',$data);
        //查询类型信息
        $this->assign('cate_data',M('cate')->select());
        $this->display();
    }
    /*
     * 商品下架操作
     */
    public function goodsDel(){
        $id=I('id');
        $msg='';
        $model=M('goods');
        $res=$model->find($id);
        if($res['goods_status']==1){
            $a['goods_status']=0;
            $msg='点击上架';
        }else{
            $a['goods_status']=1;
            $msg='点击下架';
        }
        $a['id']=$id;
        $res=$model->save($a);
        if($res){
            $this->success($msg);
        }
    }
    /*
     *商品 修改功能
     */
    public function goodsChange(){

        if(IS_POST){

            $data=I('post.');
            $model=M('goods');
//            dump($data);die;
            $res=$model->save($data);
//            echo $model->_sql();die;
            if($res){
                $this->success('修改成功');
            }else{
                $this->error('修改失败');
            }
        }
//生成品牌信息
        $brand_data=D('brand')->getList();
        $this->assign('brand_data',$brand_data);
        $id=I('id');
        $model=M('goods');
        $data=$model->field('a.*,b.brand_name')->alias('a')->join('left join brand as b on a.brand_id = b.id')->where(array('a.id'=>$id))->find();
        $this->assign('data',$data);
        $this->display();
    }

    /*
     * 相册管理
     * 展示图片 增加图片
     */
    public function pic(){
        $id=I('id');
//        echo $id;die;
        if($_FILES['image']['name'][0]!=''){
           $info= uploadFile();
           //生成缩略图
           $image=new \Think\Image();
           foreach ($info as $key => $value){
               $image->open(UPLOAD.$value['savepath'].$value['savename']);
               $image->thumb(100,100)->save(UPLOAD.$value['savepath'].'thumb_'.$value['savename']);
               $data[$key]['pic_big']=$value['savepath'].$value['savename'];
               $data[$key]['pic_small']=$value['savepath'].'thumb_'.$value['savename'];
               $data[$key]['goods_id']=$id;
           }
           $model=M('pic');
           $res=$model->addAll($data);
            if($res){
                $this->success('上传成功',U('pic','id='.$id));
            }
        }
        $model=M('pic');
        $data=$model->where(array('goods_id'=>$id))->select();
//        dump($data);die;
        $this->assign('data',$data);
        $this->display();
    }
    /*
     * 相册管理  删除图片
     */
    public function delPic(){
    $id=I('id');
    $model=M('pic');
    $data=$model->find($id);
    $res=$model->delete($id);
    //删除成功后 要进行图片的物理删除
    if($res){
        unlink(UPLOAD.$data['pic_big']);
        unlink(UPLOAD.$data['pic_small']);
        $this->success('操作成功');
    }else{
        $this->error('操作失败');
    }
    }
}