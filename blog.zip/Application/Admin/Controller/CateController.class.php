<?php
/**
 * Created by PhpStorm.
 * User: xf
 * Date: 2017/6/5
 * Time: 20:20
 */
namespace Admin\Controller;
class CateController extends CommonController
{
    public function cateList(){
        $model=M('cate');
        $data=$model->select();
        $this->assign('data',$data);
        $this->display();
    }
    public function cateAdd(){
        if(IS_POST){
            $data=I('post.');
            $model=M('Cate');
            $res=$model->add($data);
            if($res){
                $this->success('添加成功',U('cateList'));
            }else{
                $this->error('添加失败哦');
            }
            die;
        }

        $this->display();
    }

}