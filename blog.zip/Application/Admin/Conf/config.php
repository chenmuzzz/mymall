<?php
return array(
	//'配置项'=>'配置值'
    //设置cookie的前缀
    'COOKIE_PREFIX'=>'admin_'
);