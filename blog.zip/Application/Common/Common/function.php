<?php
/*
 * 防止XSS攻击 过滤危险代码
 */
function htmlPurifier($str){
    Vendor('htmlpurifier.library.HTMLPurifier#auto');
    //获取默认配置
    $config=HTMLPurifier_Config::createDefault();
    //根据配置项设置
    $purifier=new HTMLPurifier($config);
    //过滤字符串
    $clean_html=$purifier->purify($str);
    return $clean_html;
}
/*
 * 上传文件
 */
function uploadFile()
{
    $config = array(
        'maxSize' => 3145728,
        'rootPath' => './Uploads/',
    );
    $upload = new \Think\Upload($config);
    $res = $upload->upload();
    if (!$res) {
        $this->error($upload->getError());
    }
    return $res;
}

function getMenuStatus($key=0){
    $arr=array(
        '0'=>'否',
        '1'=>'是'
    );
    return $arr[$key];

}

function getTree($list,$pid=0,$level=0){
    static $arr=array();
    foreach($list as $row){
        if($row['pid'] == $pid){
            $row['level']=$level;
            $arr[]=$row;
            getTree($list,$row['id'],$level+1);
        }
    }
    return $arr;
}