<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
    <head>
        <title>添加商品</title>
        <meta http-equiv="content-type" content="text/html;charset=utf-8">
        <link href="/Public/Admin/css/mine.css" type="text/css" rel="stylesheet">
<!--引入umeditor所需的文件-->
        <link href="/Public/Admin/umeditor/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
        <script type="text/javascript" src="/Public/Admin/umeditor/third-party/jquery.min.js"></script>
        <script type="text/javascript" src="/Public/Admin/umeditor/third-party/template.min.js"></script>
        <script type="text/javascript" charset="utf-8" src="/Public/Admin/umeditor/umeditor.config.js"></script>
        <script type="text/javascript" charset="utf-8" src="/Public/Admin/umeditor/umeditor.min.js"></script>
        <script type="text/javascript" src="/Public/Admin/umeditor/lang/zh-cn/zh-cn.js"></script>
        <script src="/Public/Admin/js/jquery-1.7.2.min.js"></script>
    </head>

    <body>

        <div class="div_head">
            <span>
                <span style="float:left">当前位置是：商品管理-》添加商品信息</span>
                <span style="float:right;margin-right: 8px;font-weight: bold">
                    <a style="text-decoration: none" href="./admin.php?c=goods&a=showlist">【返回】</a>
                </span>
            </span>
        </div>
        <div></div>

        <div style="font-size: 13px;margin: 10px 5px">
            <form action="<?php echo U('goodsAdd');?>" method="post" enctype="multipart/form-data">
            <table border="1" width="100%" class="table_a">
                <tr>
                    <td>商品名称</td>
                    <td><input type="text" name="goods_name" /></td>
                </tr>
                <tr>
                    <td>商品品牌</td>
                    <td>
                        <select name="brand_id">
                            <option value="0">请选择</option>
                            <?php if(is_array($data)): foreach($data as $key=>$d): ?><option value="<?php echo ($d["id"]); ?>"><?php echo ($d["brand_name"]); ?></option><?php endforeach; endif; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>商品类型</td>
                    <td>
                        <select  class='goods_cate' name="cate_id">
                            <option value="0">请选择</option>
                            <?php if(is_array($cate_data)): foreach($cate_data as $key=>$a): ?><option value="<?php echo ($a["id"]); ?>"><?php echo ($a["cate_name"]); ?></option><?php endforeach; endif; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>商品价格</td>
                    <td><input type="text" name="goods_price" /></td>
                </tr>
                <tr>
                    <td>商品图片</td>
                    <td><input type="file" name="goods_image" /></td>
                </tr>
                 <tr>
                    <td>商品数量</td>
                    <td><input type="text" name="goods_count" /></td>
                </tr>
                <tr>
                    <td>商品排序</td>
                    <td><input type="text" name="goods_sort" /></td>
                </tr>
                <tr>
                    <td>商品详细描述</td>
                    <td>
<script type="text/plain" name="goods_descrition" id="myEditor" style="width:1000px;height:240px;">
    <p>这里我可以写一些输入提示</p></script>
                    </td>
                </tr>

                <script type="text/javascript">  //实例化编辑器
                var um = UM.getEditor('myEditor');
                </script>

                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" value="添加">
                    </td>
                </tr>
                <script>
                    $(function(){
                        $('.goods_cate').change(function(){
                            id=$(this).val();
                            $('.newTag').remove();
                            $.post('<?php echo U("attribute/sendAjax");?>',{cate_id:id},function($data){
                                console.log($data);
                                str='';
                            $.each($data,function(key,value) {
                                option='';
                                tmp='';
                                    if(value.attr_sel==0){
                                    //输入框
                                    str+='<tr class="newTag"><td>'+value.attr_name+'</td><td><input type="text" name="goods_attr['+value.id+'][]" /></td></tr>';
                                    }else{
                                        //下拉框
                                        tmp=value.attr_val.split(',');
                                        for(i=0;i<tmp.length;i++){
                                            option+='<option value="'+tmp[i]+'">'+tmp[i]+'</option>';
                                        }

                                        str+='<tr class="newTag"><td>'+value.attr_name+'</td><td><select name="goods_attr['+value.id+'][]">'+option+'</select><a href="javascript:void(0);" class="add_attr"> + </a></td></tr>'
                                    }

                            })

                                $('.goods_cate').parents('tr').after(str);
                            },'json');
                        });

                        $('.add_attr').live('click',function(){

                            trDom=$(this).parents('tr');
                            cloneDOM=trDom.clone();
                            cloneDOM.find('a').remove();
                            str='<a href="javascript:void(0);" class="mus_attr"> - </a>'
                            cloneDOM.find('select').after(str);
                            trDom.after(cloneDOM);
                        })
                        $('.mus_attr').live('click',function(){
                            $(this).parents('tr').remove();
                        })
                    })
                </script>
            </table>
            </form>
        </div>
    </body>
</html>