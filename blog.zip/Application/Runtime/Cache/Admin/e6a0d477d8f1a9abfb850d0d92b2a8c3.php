<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

        <title>相册列表</title>

        <link href="/Public/Admin/css/mine.css" type="text/css" rel="stylesheet" />
        <script src="/Public/Admin/js/jquery-1.7.2.min.js"></script>
    </head>
    <body>
        <style>
            .tr_color{background-color: #9F88FF}
        </style>
        <div class="div_head">
            <span>
                <span style="float: left;">当前位置是：相册管理-><?php echo ($_GET['id']); ?>号商品的相册列表</span>
              
            </span>
        </div>
        <div></div>
        
        <div style="font-size: 13px; margin: 10px 5px;">
            <table class="table_a" border="1" width="100%">
                <tbody><tr style="font-weight: bold;">
                        <td>序号</td>
                        <td>大图</td>
                        <td>缩略图</td>
                        <td align="center">操作</td>
                    </tr>
 <?php if(is_array($data)): foreach($data as $key=>$a): ?><tr >
                        <td><?php echo ($a["id"]); ?></td>
                        <td><img src="/Uploads/<?php echo ($a["pic_big"]); ?>" height="60" width="60"></td>
                        <td><img src="/Uploads/<?php echo ($a["pic_small"]); ?>" height="40" width="40"></td>
                   
                        <td><a class='del' data-id=<?php echo ($a["id"]); ?> href="javascript:void(0);">删除</a></td>
                    </tr><?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
         <form action="<?php echo U('pic');?>" method="post" enctype="multipart/form-data" >
             <input type="hidden" value="<?php echo ($_GET['id']); ?>" name="id">
         <div style="font-size: 13px; margin: 10px 5px;">
            <table class="table_a" border="1" width="100%">
             
                    <tr style="font-weight: bold;">
                        <td>选择图片<a href="javascript:void(0);" id='add'>[+]</a></td>
                       
                    </tr>
                  <tbody id="img_files">
                    <tr>
                        <td><input type="file" name='image[]'/><a class='pic_del' href='javascript:void(0);'>[-]</a></td>
                    </tr>
                </tbody>

            </table>
             <input type="submit" value="确认保存">
         </div>
         </form>
    <script>
        $(function () {
//            增加文本域
            $('#add').click(function(){
                str="<tr><td><input type='file' name='image[]'/><a class='pic_del' href='javascript:void(0);'>[-]</a></td></tr>";
                $('#img_files').append(str);
            });
//              删除文件选择文本域
            $('.pic_del').live('click',function(){
                $(this).parents('tr').remove();
            });
          //  删除图片
            $('.del').live('click',function(){
                _this=$(this);
                id=_this.attr('data-id');
                $.post('/index.php/Admin/Goods/delPic','id='+id,function(data){
                    if(data.status==1){
                        _this.parents('tr').remove();
                    }
                },'json')
            })
        })
    </script>
    </body>
</html>