<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

        <title>会员列表</title>

        <link href="/Public/Admin/css/mine.css" type="text/css" rel="stylesheet" />
        <script src="/Public/Admin/js/jquery-1.7.2.min.js"></script>
    </head>
    <body>
        <style>
            .tr_color{background-color: #9F88FF}
        </style>
        <div class="div_head">
            <span>
                <span style="float: left;">当前位置是：商品管理->商品列表</span>
                <span style="float: right; margin-right: 8px; font-weight: bold;">
                    <a style="text-decoration: none;" href="<?php echo U('goodsAdd');?>">【添加商品】</a>
                </span>
            </span>
        </div>
        <div></div>
        
        <div style="font-size: 13px; margin: 10px 5px;">
            <table class="table_a" border="1" width="100%">
                <tbody><tr style="font-weight: bold;">
                        <td>序号</td>
                        <td>商品名称</td>
                         <td>分类</td>
                         <td>品牌</td>
                        <td>库存</td>
                        <td>价格</td>
                        <td>缩略图</td>

                        <td>创建时间</td>

                        <td align="center" colspan="3">操作</td>
                    </tr>
                <?php if(is_array($data)): foreach($data as $key=>$d): ?><tr id="product1">
                        <td class="image_id"><?php echo ($d["id"]); ?></td>
                        <td><a href="#"><?php echo ($d["goods_name"]); ?></a></td>
                        <td><?php echo ($d["brand_id"]); ?></td>
                        <td><?php echo ($d["brand_name"]); ?></td>
                        <td><?php echo ($d["goods_count"]); ?></td>
                        <td><?php echo ($d["goods_price"]); ?></td>
                        <td><img src="/Uploads/<?php echo ($d["goods_smallpic"]); ?>" height="40" width="40"></td>

                        <td>2012-10-18 17:40:34</td>
                        <td><a href="<?php echo U('pic','id='.$d['id']);?>">相册管理</a></td>
                        <td><a href="<?php echo U('goodsChange','id='.$d['id']);?>">修改</a></td>
                        <td><a href="javascript:;" class="image_del" data-id="<?php echo ($d["id"]); ?>">
                            <?php if($d['goods_status']==1): ?>点击下架<?php else: ?>点击上架<?php endif; ?>
                        </a></td>
                    </tr><?php endforeach; endif; ?>

                    <tr>
                        <td colspan="20" style="text-align: center;">
                            <?php echo ($pages); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    <script>
            $('.image_del').click(function(){
                id=$(this).attr('data-id');
                _this=$(this);
               //发送AJAX请求
                $.post('/index.php/Admin/Goods/goodsDel',{'id':id},function(datas){
//                    console.log(datas);
                    _this.text(datas.info);
                },'json');
            })

    </script>
    </body>
</html>